# Abgabe zum Blatt 01 von Sven Ullmann und Valentin Adam 
- PDF 01_Adam_Ullmann enthält alle Beschreibungen und Abbildungen zur Beantwortung der Aufgaben 
- adam_ullmann.ipynb enthält den zugehörigen code und weitere Abbildungen 